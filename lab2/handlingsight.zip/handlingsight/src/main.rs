/******************************************************************************
Handling SIGINT and foward notification

*******************************************************************************/
use std::sync::mpsc;
use std::thread;
use signal_hook::consts::SIGCONT;
use signal_hook::iterator::Signals;

fn main() {
    let (tx, rx) = mpsc::channel();

    // Thread A: listens for SIGCONT and sends a message
    let signal_thread = thread::spawn(move || {
        let mut signals = Signals::new([SIGCONT]).unwrap();
        for _ in signals.forever() {
            tx.send(()).unwrap();
        }
    });

    // Thread B: receives messages and prints them
    let recv_thread = thread::spawn(move || { 
        for _ in rx.iter() {
            println!("Received SIGCONT!");
        }
        println!("Receiver thread exiting.");
    });

    println!("Program running. Press Ctrl-Z to send SIGCONT.");

    // Wait for both threads to finish
    signal_thread.join().unwrap();
    recv_thread.join().unwrap();

    println!("All threads finished.");
}
